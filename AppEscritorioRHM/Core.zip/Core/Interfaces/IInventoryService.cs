﻿using AppEscritorioRHM.Core.Models.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace AppEscritorioRHM.Core.Interfaces
{
    public interface IInventoryService
    {
        Task SyncInventoryFromExcelAsync(string excelPath, string cacheDirectory, IProgress<ProgressInfo> progress, CancellationToken ct);
        Task DownloadAndCacheProductsAsync(string cacheDirectory, IProgress<ProgressInfo> progress, CancellationToken ct);
    }
}
