﻿using AppEscritorioRHM.Core.Interfaces;
using AppEscritorioRHM.Core.Models.Domain;
using AppEscritorioRHM.Core.Models.DTOs.WooCommerce;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
/*
namespace AppEscritorioRHM.Core.Services
{

    //TODO: MEJORAR LA CLASE RECIÉN CREADA
    public class InventoryService : IInventoryService
    {
        private readonly IWCService _wcService;
        private const string STOCK_INSTOCK = "instock";
        private const string STOCK_OUTOFSTOCK = "outofstock";
        private readonly int[] _categoriesToSync = [1518, 1519]; // Antilo y Fundeco

        public InventoryService(IWCService wcService)
        {
            _wcService = wcService;
        }

        public async Task SyncInventoryFromExcelAsync(string excelPath, string cacheDirectory, IProgress<ProgressInfo> progress, CancellationToken ct)
        {
            // 1. Cargar Caches
            var (variations, simples, parents) = await LoadCacheAsync(cacheDirectory);

            // 2. Leer Excel
            var excelData = ReadExcelData(excelPath);

            int totalItems = variations.Count + simples.Count;
            int current = 0;

            // 3. Procesar Variaciones
            foreach (var v in variations)
            {
                ct.ThrowIfCancellationRequested();
                if (excelData.TryGetValue(v.sku ?? string.Empty, out string? excelStatus))
                {
                    string? newStatus = DetermineNewStatus(v.stock_status, excelStatus);
                    if (newStatus != null)
                    {
                        int parentId = parents.GetValueOrDefault(v.id);
                        await UpdateStockAsync(parentId, v.id, newStatus, true);
                        v.stock_status = newStatus;
                    }
                }
                progress.Report(new ProgressInfo(++current, totalItems, v.id));
            }

            // 4. Procesar Simples
            foreach (var s in simples)
            {
                if (s.id == null) continue;
                ct.ThrowIfCancellationRequested();
                if (excelData.TryGetValue(s.sku ?? string.Empty, out string? excelStatus))
                {
                    string? newStatus = DetermineNewStatus(s.stock_status, excelStatus);
                    if (newStatus != null)
                    {
                        await UpdateStockAsync(s.id!.Value, null, newStatus, false);
                        s.stock_status = newStatus;
                    }
                }
                progress.Report(new ProgressInfo(++current, totalItems, s.id));
            }

            // 5. Guardar cambios en cache
            await SaveCacheAsync(cacheDirectory, variations, simples);
        }

        private string? DetermineNewStatus(string currentStatus, string excelValue)
        {
            if (currentStatus == STOCK_INSTOCK && (excelValue == "DESCATALOGADO" || excelValue == "EN FABRICACIÓN"))
                return STOCK_OUTOFSTOCK;

            if (currentStatus == STOCK_OUTOFSTOCK && (excelValue == "MENOS DE 5" || excelValue == "DISPONIBLE"))
                return STOCK_INSTOCK;

            return null;
        }

        private async Task UpdateStockAsync(int parentId, int? variationId, string status, bool isVariation)
        {
            var updateDto = new { stock_status = status };
            string endpoint = isVariation
                ? $"products/{parentId}/variations/{variationId}"
                : $"products/{parentId}";

            await _wcService.PutAsync<object>(endpoint, updateDto);
        }

        private Dictionary<string, string> ReadExcelData(string filePath)
        {
            var data = new Dictionary<string, string>();
            using var doc = SpreadsheetDocument.Open(filePath, false);
            var workbookPart = doc.WorkbookPart!;
            var sheet = workbookPart.Workbook.Sheets!.GetFirstChild<Sheet>()!;
            var worksheetPart = (WorksheetPart)workbookPart.GetPartById(sheet.Id!);

            var rows = worksheetPart.Worksheet.Descendants<Row>().Where(r => r.RowIndex! >= 13);
            foreach (var row in rows)
            {
                var cellC = row.Elements<Cell>().FirstOrDefault(c => c.CellReference?.Value?.StartsWith("C") == true);
                var cellE = row.Elements<Cell>().FirstOrDefault(c => c.CellReference?.Value?.StartsWith("E") == true);

                if (cellC == null || cellE == null) continue;

                string sku = GetCellValue(doc, cellC);
                string status = GetCellValue(doc, cellE);

                if (!string.IsNullOrEmpty(sku)) data[sku] = status;
            }
            return data;
        }

        private string GetCellValue(SpreadsheetDocument doc, Cell cell)
        {
            string value = cell.CellValue?.InnerText ?? string.Empty;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return doc.WorkbookPart!.SharedStringTablePart!.SharedStringTable.ElementAt(int.Parse(value)).InnerText;
            }
            return value;
        }

        public async Task DownloadAndCacheProductsAsync(string cacheDirectory, IProgress<ProgressInfo> progress, CancellationToken ct)
        {
            var allProducts = new List<ProductWooDTO>();

            foreach (var catId in _categoriesToSync)
            {
                progress.Report(new ProgressInfo(0, null, catId));
                int page = 1;
                while (true)
                {
                    ct.ThrowIfCancellationRequested();
                    var products = await _wcService.GetAsync<List<ProductWooDTO>>($"products?category={catId}&page={page}&per_page=100");

                    if (products == null || products.Count == 0) break;

                    allProducts.AddRange(products);
                    progress.Report(new ProgressInfo(allProducts.Count, null, null));
                    page++;
                }
            }

            var simpleProducts = allProducts.Where(p => p.type == "simple").ToList();
            var variableProducts = allProducts.Where(p => p.type == "variable").ToList();

            var allVariations = new ConcurrentBag<ProductVariationsWooDTO>();
            var parentMap = new ConcurrentDictionary<int, int>();

            progress.Report(new ProgressInfo(0, variableProducts.Count, null));
            using var semaphore = new SemaphoreSlim(2);
            int processedVariables = 0;

            var tasks = variableProducts.Select(async p =>
            {
                await semaphore.WaitAsync(ct);
                try
                {
                    ct.ThrowIfCancellationRequested();
                    var variations = await GetVariationsAsync(p.id!.Value, ct);
                    foreach (var v in variations)
                    {
                        allVariations.Add(v);
                        parentMap.TryAdd(v.id, p.id!.Value);
                    }
                    Interlocked.Increment(ref processedVariables);
                    progress.Report(new ProgressInfo(processedVariables, variableProducts.Count, p.id));
                }
                finally
                {
                    semaphore.Release();
                }
            });

            await Task.WhenAll(tasks);

            await SaveCacheAsync(cacheDirectory, allVariations.ToList(), simpleProducts, parentMap.ToDictionary(kvp => kvp.Key, kvp => kvp.Value));
        }

        private async Task<List<ProductVariationsWooDTO>> GetVariationsAsync(int productId, CancellationToken ct)
        {
            var results = new List<ProductVariationsWooDTO>();
            int page = 1;
            while (true)
            {
                ct.ThrowIfCancellationRequested();
                var items = await _wcService.GetAsync<List<ProductVariationsWooDTO>>($"products/{productId}/variations?page={page}&per_page=100");
                if (items == null || items.Count == 0) break;
                results.AddRange(items);
                page++;
            }
            return results;
        }

        private async Task<(List<ProductVariationsWooDTO>, List<ProductWooDTO>, Dictionary<int, int>)> LoadCacheAsync(string path)
        {
            var variationsPath = Path.Combine(path, "variations.json");
            var simplesPath = Path.Combine(path, "simples.json");
            var parentsPath = Path.Combine(path, "parents.json");

            var variations = File.Exists(variationsPath) ? JsonConvert.DeserializeObject<List<ProductVariationsWooDTO>>(await File.ReadAllTextAsync(variationsPath)) : new();
            var simples = File.Exists(simplesPath) ? JsonConvert.DeserializeObject<List<ProductWooDTO>>(await File.ReadAllTextAsync(simplesPath)) : new();
            var parents = File.Exists(parentsPath) ? JsonConvert.DeserializeObject<Dictionary<int, int>>(await File.ReadAllTextAsync(parentsPath)) : new();

            return (variations ?? new(), simples ?? new(), parents ?? new());
        }

        private async Task SaveCacheAsync(string path, List<ProductVariationsWooDTO> v, List<ProductWooDTO> s, Dictionary<int, int>? p = null)
        {
            Directory.CreateDirectory(path);
            await File.WriteAllTextAsync(Path.Combine(path, "variations.json"), JsonConvert.SerializeObject(v, Formatting.None));
            await File.WriteAllTextAsync(Path.Combine(path, "simples.json"), JsonConvert.SerializeObject(s, Formatting.None));
            if (p != null)
            {
                await File.WriteAllTextAsync(Path.Combine(path, "parents.json"), JsonConvert.SerializeObject(p, Formatting.None));
            }
        }
    }
}
*/