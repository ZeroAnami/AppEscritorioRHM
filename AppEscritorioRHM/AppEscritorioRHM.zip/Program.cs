using AppEscritorioRHM.Controls;
using AppEscritorioRHM.Core.Interfaces;
using AppEscritorioRHM.Core.Models;
using AppEscritorioRHM.Core.Services;
using AppEscritorioRHM.Core.Utilities;
using AppEscritorioRHM.Properties;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.Http.Headers;
using System.Text;

namespace AppEscritorioRHM
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            Application.SetDefaultFont(new Font(new FontFamily("Microsoft Sans Serif"), 9f));
            var services = new ServiceCollection();
            ConfigureServices(services);
            var serviceProvider = services.BuildServiceProvider();
            var settings = serviceProvider.GetRequiredService<AppSettings>();

            bool loginOk = checkLoging(serviceProvider).GetAwaiter().GetResult();

            if (!loginOk) return; //Verifica si la configuraci�n b�sica es correcta

            Uri myUri = new Uri(settings.DominioWeb);
            var mainForm = serviceProvider.GetRequiredService<MainForm>();
            mainForm.Text = $"Gesti�n de productos {myUri.Host}";
           
            Application.Run(mainForm);

        }

        private static void ConfigureServices(IServiceCollection services)
        {
            // Configuraci�n
            services.AddSingleton<AppSettings>();
            services.AddTransient<RedirecctionUrlUserControl>();
            services.AddTransient<MainForm>();

            // Servicios
            services.AddTransient<IBrandMapper, BrandMapperService>();
            services.AddTransient<IRedirectService, RedirectService>();
            services.AddTransient<IProductService, ProductWooService>();
            //services.AddTransient<RedirectionOrchestrator>(); Obsoleto

            services.AddHttpClient<IWCService, WCService>(client =>
            {
                client.BaseAddress = new Uri($"{SecurityService.Decrypt(Settings.Default.Dominio)}{WCEndpoints.EndpointWC}");
                client.Timeout = TimeSpan.FromMinutes(10);

                string key = SecurityService.Decrypt(Settings.Default.yourConsumerKeyWC);
                string secret = SecurityService.Decrypt(Settings.Default.yourConsumerSecretWC);

                if (!string.IsNullOrEmpty(key))
                {
                    var authBytes = Encoding.ASCII.GetBytes($"{key}:{secret}");
                    client.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authBytes));
                }
            });

            services.AddHttpClient<IWPService, WPService>(client =>
            {
                client.BaseAddress = new Uri($"{SecurityService.Decrypt(Settings.Default.Dominio)}{WCEndpoints.EndpointWP}");
                client.Timeout = TimeSpan.FromMinutes(10);

                string key = SecurityService.Decrypt(Settings.Default.yourConsumerKeyWC);
                string secret = SecurityService.Decrypt(Settings.Default.yourConsumerSecretWC);

                if (!string.IsNullOrEmpty(key))
                {
                    var authBytes = Encoding.ASCII.GetBytes($"{key}:{secret}");
                    client.DefaultRequestHeaders.Authorization =
                        new AuthenticationHeaderValue("Basic", Convert.ToBase64String(authBytes));
                }
            });
        }

        private async static Task<bool> checkLoging(ServiceProvider serviceProvider)
        {
            if (String.IsNullOrEmpty(Settings.Default.Dominio) ||
                String.IsNullOrEmpty(Settings.Default.yourConsumerKeyWC) ||
                String.IsNullOrEmpty(Settings.Default.yourConsumerSecretWC) ||
                String.IsNullOrEmpty(Settings.Default.yourConsumerKeyWP) ||
                String.IsNullOrEmpty(Settings.Default.yourConsumerSecretWP)
                )
            {
                var formConfig = new FormConfig();
                DialogResult result = formConfig.ShowDialog();
                if (result != DialogResult.OK) return false;
            }

            bool connectionCheck = false;
            while (!connectionCheck)
            {
                var wcService = serviceProvider.GetRequiredService<IWCService>();

                try
                {
                    if (string.IsNullOrEmpty(Settings.Default.Dominio))
                    {
                        connectionCheck = false;
                    }
                    else
                    {
                        connectionCheck = await wcService.CheckConnectionAsync();
                    }
                }
                catch
                {
                    connectionCheck = false;
                }

                if (connectionCheck) return true;

                DialogResult messageBoxResult = MessageBox.Show(
                    "No se puede conectar con WooCommerce.\n�Quieres abrir la configuraci�n?",
                    "Error de Conexi�n",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                    );
                if (messageBoxResult == DialogResult.No) return false;

                var formConfig = new FormConfig();
                DialogResult configResult = formConfig.ShowDialog();
                if (configResult != DialogResult.OK) return false;
            }
            return false;
        }
    }
}