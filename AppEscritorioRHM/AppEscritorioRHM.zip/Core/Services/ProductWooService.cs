﻿using AppEscritorioRHM.Core.Interfaces;
using AppEscritorioRHM.Core.Models.Domain;
using AppEscritorioRHM.Core.Models.DTOs.WooCommerce;
using AppEscritorioRHM.Core.Utilities;
using CsvHelper;
using CsvHelper.Configuration;
using System.Globalization;
using System.Text.RegularExpressions;

namespace AppEscritorioRHM.Core.Services
{
    public class ProductWooService : IProductService
    {
        private readonly AppSettings _settings;
        private readonly IWCService _WCService;

        public ProductWooService(IWCService WCService, AppSettings settings)
        {
            _settings = settings;
            _WCService = WCService;
        }
        public async Task<List<Product>> GetProductsFromIdsAsync(
            List<int> ids,
            IProgress<ProgressInfo> progress = null,
            CancellationToken ct = default)
        {
            return await ids.ProcessWithSemaphoreAsync(
                semaphore: _WCService.getSemaphore(),
                body: (id, token) => _WCService.GetProductByIdAsync(id, token),
                progress: progress,
                ct: ct
            );
            /*var tasks = new List<Task<Product>>();
            int contador = 0;

            object lockReporte = new object();

            foreach (var id in ids)
            {
                ct.ThrowIfCancellationRequested();
                await _semaphore.WaitAsync(ct);

                var task = Task.Run(async () =>
                {
                    try
                    {
                        Product p = await _WCService.GetProductByIdAsync(id, ct);

                        lock (lockReporte)
                        {
                            progress?.Report(new ProgressInfo(++contador, ids.Count, id));
                        }

                        return p;
                    }
                    finally
                    {
                        _semaphore.Release();
                    }
                }, ct);

                tasks.Add(task);
            }
            var results = await Task.WhenAll(tasks);
            return results.ToList();*/
        }

        public List<int> getIdsFromCsvAsync(string pathToFile)
        {
            // Detectar si el delimitador es coma o punto y coma leyendo la cabecera
            string delimiter = ",";
            using (var streamReader = new StreamReader(pathToFile))
            {
                string headerLine = streamReader.ReadLine();
                if (headerLine != null && headerLine.Contains(';'))
                {
                    delimiter = ";";
                }
            }

            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                Delimiter = delimiter,
                HasHeaderRecord = true,
                PrepareHeaderForMatch = args => args.Header.ToLower(),
            };

            var ids = new List<int>();

            using (var reader = new StreamReader(pathToFile))
            using (var csv = new CsvReader(reader, config))
            {
                csv.Read();
                csv.ReadHeader();

                while (csv.Read())
                {
                    string tipo = csv.GetField("Tipo");
                    string idStr = csv.GetField("ID");

                    if (tipo == "variable" && int.TryParse(idStr, out int id))
                    {
                        ids.Add(id);
                    }
                }
            }
            return ids;
        }
    }
}
