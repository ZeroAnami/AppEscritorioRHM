﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace AppEscritorioRHM.Core.Models.DTOs.WooCommerce
{
    /// <summary>
    /// DTO Principal que representa la respuesta completa del adjunto (Imagen)
    /// </summary>
    public class AttachmentWpDTO
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("date")]
        public DateTime? Date { get; set; }

        [JsonPropertyName("date_gmt")]
        public DateTime? DateGmt { get; set; }

        [JsonPropertyName("guid")]
        public RenderedFieldWpDTO Guid { get; set; }

        [JsonPropertyName("modified")]
        public DateTime? Modified { get; set; }

        [JsonPropertyName("modified_gmt")]
        public DateTime? ModifiedGmt { get; set; }

        [JsonPropertyName("slug")]
        public string Slug { get; set; }

        [JsonPropertyName("status")]
        public string Status { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("link")]
        public string Link { get; set; }

        [JsonPropertyName("title")]
        public RenderedFieldWpDTO Title { get; set; }

        [JsonPropertyName("author")]
        public int Author { get; set; }

        [JsonPropertyName("comment_status")]
        public string CommentStatus { get; set; }

        [JsonPropertyName("ping_status")]
        public string PingStatus { get; set; }

        [JsonPropertyName("template")]
        public string Template { get; set; }

        [JsonPropertyName("meta")]
        public List<object> Meta { get; set; }

        [JsonPropertyName("class_list")]
        public List<string> ClassList { get; set; }

        [JsonPropertyName("description")]
        public RenderedFieldWpDTO Description { get; set; }

        [JsonPropertyName("caption")]
        public RenderedFieldWpDTO Caption { get; set; }

        [JsonPropertyName("alt_text")]
        public string AltText { get; set; }

        [JsonPropertyName("media_type")]
        public string MediaType { get; set; }

        [JsonPropertyName("mime_type")]
        public string MimeType { get; set; }

        [JsonPropertyName("media_details")]
        public MediaDetailsWpDTO MediaDetails { get; set; }

        [JsonPropertyName("post")]
        public int? PostParentId { get; set; }

        [JsonPropertyName("source_url")]
        public string SourceUrl { get; set; }

        [JsonPropertyName("_links")]
        public LinksDTOWp Links { get; set; }
    }

    // =========================================================
    // CLASES AUXILIARES (Anidadas en el JSON)
    // =========================================================

    /// <summary>
    /// Para campos que vienen con la propiedad "rendered" (Title, Guid, Description)
    /// </summary>
    public class RenderedFieldWpDTO
    {
        [JsonPropertyName("rendered")]
        public string Rendered { get; set; }
    }

    /// <summary>
    /// Detalles técnicos del archivo multimedia
    /// </summary>
    public class MediaDetailsWpDTO
    {
        [JsonPropertyName("width")]
        public int Width { get; set; }

        [JsonPropertyName("height")]
        public int Height { get; set; }

        [JsonPropertyName("file")]
        public string File { get; set; }

        [JsonPropertyName("filesize")]
        public long? Filesize { get; set; }

        /// <summary>
        /// Diccionario clave-valor para soportar tamaños dinámicos 
        /// (ej: "medium", "woocommerce_thumbnail", "1536x1536")
        /// </summary>
        [JsonPropertyName("sizes")]
        public Dictionary<string, ImageSizeWpDTO> Sizes { get; set; }

        [JsonPropertyName("image_meta")]
        public ImageMetaWpDTO ImageMeta { get; set; }
    }

    /// <summary>
    /// Representa cada variante de tamaño de la imagen
    /// </summary>
    public class ImageSizeWpDTO
    {
        [JsonPropertyName("file")]
        public string File { get; set; }

        [JsonPropertyName("width")]
        public int Width { get; set; }

        [JsonPropertyName("height")]
        public int Height { get; set; }

        [JsonPropertyName("filesize")]
        public long? Filesize { get; set; }

        [JsonPropertyName("mime_type")]
        public string MimeType { get; set; }

        [JsonPropertyName("source_url")]
        public string SourceUrl { get; set; }

        [JsonPropertyName("uncropped")]
        public bool? Uncropped { get; set; }
    }

    /// <summary>
    /// Metadatos EXIF de la imagen (Cámara, apertura, etc.)
    /// </summary>
    public class ImageMetaWpDTO
    {
        [JsonPropertyName("aperture")]
        public string Aperture { get; set; }

        [JsonPropertyName("credit")]
        public string Credit { get; set; }

        [JsonPropertyName("camera")]
        public string Camera { get; set; }

        [JsonPropertyName("caption")]
        public string Caption { get; set; }

        [JsonPropertyName("created_timestamp")]
        public string CreatedTimestamp { get; set; }

        [JsonPropertyName("copyright")]
        public string Copyright { get; set; }

        [JsonPropertyName("focal_length")]
        public string FocalLength { get; set; }

        [JsonPropertyName("iso")]
        public string Iso { get; set; }

        [JsonPropertyName("shutter_speed")]
        public string ShutterSpeed { get; set; }

        [JsonPropertyName("title")]
        public string Title { get; set; }

        [JsonPropertyName("orientation")]
        public string Orientation { get; set; }

        // Keywords suele venir vacío, pero es una lista
        [JsonPropertyName("keywords")]
        public List<string> Keywords { get; set; }
    }

    // =========================================================
    // CLASES PARA LOS LINKS (HATEOAS)
    // =========================================================
    // Opcional: Solo si necesitas navegar por los links "_links"

    public class LinksDTOWp
    {
        [JsonPropertyName("self")]
        public List<LinkItemDTOWp> Self { get; set; }

        [JsonPropertyName("collection")]
        public List<LinkItemDTOWp> Collection { get; set; }

        [JsonPropertyName("about")]
        public List<LinkItemDTOWp> About { get; set; }

        [JsonPropertyName("author")]
        public List<LinkItemDTOWp> Author { get; set; }

        [JsonPropertyName("replies")]
        public List<LinkItemDTOWp> Replies { get; set; }
    }

    public class LinkItemDTOWp
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }

        [JsonPropertyName("embeddable")]
        public bool? Embeddable { get; set; }
    }
}
