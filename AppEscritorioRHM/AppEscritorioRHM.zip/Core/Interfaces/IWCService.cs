﻿using AppEscritorioRHM.Core.Models.Domain;
using AppEscritorioRHM.Core.Models.DTOs.WooCommerce;
using System;
using System.Collections.Generic;
using System.Text;

namespace AppEscritorioRHM.Core.Interfaces
{
    public interface IWCService
    {
        SemaphoreSlim getSemaphore();
        Task<Product> GetProductByIdAsync(int id, CancellationToken ct = default);
        Task<Product> DeleteProductByIdAsync(int id, CancellationToken ct = default);
        Task<List<Product>> GetProductsByPageAsync(int page, int perPage = 100, CancellationToken ct = default);
        Task<List<Product>> GetAllProductsAsync(IProgress<ProgressInfo> progress = null, CancellationToken ct = default);
        Task<Category> GetCategoryByIdAsync(int id, CancellationToken ct = default);
        Task<List<ProductVariationsWooDTO>> GetProductVariationsAsync(int parentId, CancellationToken ct = default);
        Task<ProductVariationsWooDTO> GetProductVariationAsync(int parentId, int id, CancellationToken ct = default);
        Task<List<Category>> GetCategoriesAsync(CancellationToken ct = default);
        Task<bool> CheckConnectionAsync();
    }
}
